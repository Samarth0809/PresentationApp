package com.ty.presentationApp.enums;

public enum Role {
	ADMIN, STUDENT
}
