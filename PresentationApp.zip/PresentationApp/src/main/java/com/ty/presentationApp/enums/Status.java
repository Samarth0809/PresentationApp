package com.ty.presentationApp.enums;

public enum Status {
	ACTIVE, INACTIVE

}
