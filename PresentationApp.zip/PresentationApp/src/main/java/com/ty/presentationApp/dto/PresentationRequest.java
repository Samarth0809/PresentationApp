package com.ty.presentationApp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PresentationRequest {
	private String course;
	
	private String topic;
	
}
