package com.ty.presentationApp.enums;

public enum PresentationStatus {
	ASSIGNED,COMPLETED,ONGOING
}
