package com.ty.presentationApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresentationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
